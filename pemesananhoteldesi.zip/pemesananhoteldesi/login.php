<?php
require_once "header.php";
?>

<div class="container col-4 mb-5">
    <div class="card">
    <div class="card-header">Login</div>
    <form method="POST">
        <div class="mb-2">
             <label for="username">username</label>
            <input id="username" type="text"class="form-control"
            name="username" required>
        </div>
        <div class="mb-2">
            <label for="password">password</label>
            <input id="password" type="password" class="form-control" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary"
        name="login">Login</button>
    </form>
</div>
<?php
    if(isset($_POST['login'])){
       /*  $username = mysqli_real_escape_string($koneksi,$_POST['username']);
        $password = mysqli_real_escape_string($koneksi,$_POST['password']); */
        $username = $_POST['username'];
        $password = $_POST['password'];
        //$sql="SELECT * FROM petugas WHERE username='$username' AND password='$password'";
        //var_dump($sql);die();
        $sql2=mysqli_query($koneksi,"SELECT * FROM petugas WHERE username='$username' AND password='$password'");
        $cek2=mysqli_num_rows($sql2);
		$data2=mysqli_fetch_assoc($sql2);

//var_dump($data2);die();
       
     if($cek2>0){
            //var_dump($cek2);die();
        if($data2['level']=='admin'){
        //var_dump($data2);die();
        //echo "$data2['level']";die();
            session_start();
            $_SESSION['username']=$username;
            $_SESSION['data']=$data2;
            header('location:admin/');
        }
        elseif($data2['level']=='resepsionis'){
            session_start();
            $_SESSION['username']=$username;
            $_SESSION['data']=$data2;
            header('location:resepsionis/');
            }
        }
        else{
            echo"<script>alert('Gagal login Sob')
			</script>";
        }

    }
?>

<?php
require_once "footer.php"
?>