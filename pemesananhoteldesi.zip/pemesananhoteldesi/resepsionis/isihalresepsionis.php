<?php
    if(isset($_GET['modul'])){
        $page=$_GET['modul'];
        switch ($page) {
            case 'reservasi':
                if(isset($_GET['aksi'])){
                    $act=$_GET['aksi'];
                    switch ($act) {
                        case 'tambah':
                            include("tambahreservasi.php");
                            break;
                        case 'update':
                            include("updatereservasi.php");
                            break;
                        case 'delete':
                            include("hapusreservasi.php");
                            break;
                    }
                }
                else{
                    include "datareservasi.php";
                    break;
                }
                break;
            case 'checkin':
                    include "datacheckin.php";
                    break;
                    
                case 'tamu':
                        include "datatamu.php";
                        break;
                }
        }
?>