<?php
require('../config/reservasi.php');
?>
<!--Membuat tabel data admin-->
<a href="index.php?modul=reservasi&aksi=tambah"><button>Tambah Data</button></a>

<?php
$sql="SELECT * from vpemesan";
$query=mysqli_query($koneksi,$sql);
?>
<table class="table-bordered" border=1>
    <tr>
        <th>KodePesan</th>
        <th>Id Tamu</th>
        <th>Nama Tamu</th>
		<th>Email</th>
        <th>check-In</th>
		<th>Check-Out</th>
        <th>Tipekamar</th>
        <th>tglpesan</th>
        <th>status</th>
        <th colspan="2" style="text-align: center;">Aksi</th>
    </tr>
    <?php
    while($baris=mysqli_fetch_assoc($query)){
        ?>
    <tr>
        <td><?= $baris['kodepesan'];?></td>
        <td><?= $baris['id_tamu'];?></td>
        <td><?= $baris['nama_tamu'];?></td>
        <td><?= $baris['email'];?></td>
        <td><?= $baris['checkin'];?></td>
        <td><?= $baris['checkout'];?></td>
		<td><?= $baris['tipekamar'];?></td>
        <td><?= $baris['tglpesan'];?></td>
        <td><?= $baris['status'];?></td>
        <td><a href="index.php?modul=reservasi&aksi=update&id=<?= $baris['kodepesan'];?>">Update</a></td>
        <td><a href="index.php?modul=reservasi&aksi=delete&id=<?= $baris['kodepesan'];?>">Delete</a></td>
    </tr>
    <?php
    }
    ?>
</table>
