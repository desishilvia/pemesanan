<?php
require('../config/reservasi.php');

?>
<form method="POST" action="index.php?modul=tamu">
  <div class="row mb-3">
    <label for="nama_tamu" class="col-sm-2 col-form-label">Nama Tamu</label>
    <div class="col-sm-10">
      <input type="txt" class="form-control" id="nama_tamu" name="txtnama_tamu">
    </div>
  </div>
  
  <button type="submit" class="btn btn-primary" name="filter">filter</button>
</form>
<?php
if(isset($_POST['filter'])){
$nama_tamu=$_POST['txtnama_tamu'];
$sql="SELECT * from vpemesan where nama_tamu='$nama_tamu'";
//var_dump($sql);die();
$query=mysqli_query($koneksi,$sql);
?>
<table class="table-bordered" border=1>
    <tr>
        <th>Kode Pesan</th>
        <th>Id Tamu</th>
        <th>Nama Tamu</th>
		<th>Email</th>
        <th>check-In</th>
		<th>Check-Out</th>
        <th>Tipekamar</th>
        <th>tglpesan</th>
        <th>status</th>
        <th colspan="2" style="text-align: center;">Aksi</th>
    </tr>
    <?php
    while($baris=mysqli_fetch_assoc($query)){
        ?>
    <tr>
        <td><?= $baris['kodepesan'];?></td>
        <td><?= $baris['id_tamu'];?></td>
        <td><?= $baris['nama_tamu'];?></td>
        <td><?= $baris['email'];?></td>
        <td><?= $baris['checkin'];?></td>
        <td><?= $baris['checkout'];?></td>
		<td><?= $baris['tipekamar'];?></td>
        <td><?= $baris['tglpesan'];?></td>
        <td><?= $baris['status'];?></td>
        <td><a href="index.php?modul=reservasi&aksi=update&id=<?= $baris['kodepesan'];?>">Update</a></td>
        <td><a href="index.php?modul=reservasi&aksi=delete&id=<?= $baris['kodepesan'];?>">Delete</a></td>
    </tr>
    <?php
    }
    ?>
</table>
<?php
}
?>