<?php
    require("../koneksi.php");
    
    if(isset($_POST['simpan'])){
        $kodepesan=htmlspecialchars(trim($_POST['txtkodepesan']));
        $id_tamu=htmlspecialchars(trim($_POST['txtid_tamu']));
        $checkin=htmlspecialchars(trim($_POST['datecheckin']));
        $checkout=htmlspecialchars(trim($_POST['datecheckout']));
        $tipe_kamar=htmlspecialchars(trim($_POST['txttipe_kamar']));
        $tglpesan=htmlspecialchars(trim($_POST['datetglpesan']));
        $status=htmlspecialchars(trim($_POST['txtstatus']));
        $sql="insert into reservasi($kodepesan,$id_tamu,$checkin,$checkout,$tipe_kamar,$tglpesan,$status) value('$kodepesan','$id_tamu',$'checkin',$'checkout','$tipe_kamar','$tglpesan','$status')";
        mysqli_query($koneksi,$sql);
        //var_dump($kamar);die();
        header("location:index.php?modul=reservasi");
    }
    else{
        if(isset($_GET['id'])){
            $id=$_GET['id'];
            $sql="select * from vpemesan where kodepesan='$id'";
            $query=mysqli_query($koneksi,$sql);
            while($data=mysqli_fetch_assoc($query)){
            
    ?>

    <!-- Buat Form untuk menampilkan data update --> 
    <form action="updatereservasi.php" method="post">
        <div class="col-md-12 mb-2">
            <label for="txtkodepesan">Kode Pesan</label>
            <input type="text" name="txtkodepesan" id="txtkodepesan"
            class="form-control" value="<?=$data['kodepesan'];?>">
        </div>
        <div class="col-md-12 mb-2">
            <label for="txtid_tamu">Id Tamu</label>
            <input type="text" name="txtid_tamu" id="txtid_tamu"
            class="form-control" value="<?=$data['id_tamu'];?>">
        </div>
        <div class="col-md-12 mb-2">
            <label for="datecheckin">Checkin</label>
            <input type="date" name="datecheckin" id="datecheckin"
            class="form-control" value="<?=$data['checkin'];?>">
        </div>
        <div class="col-md-12 mb-2">
            <label for="datecheckout">Checkout</label>
            <input type="date" name="datecheckout" id="datecheckout"
            class="form-control" value="<?=$data['checkout'];?>">
        </div>
        <?php
        $sqlkamar="select tipe_kamar from kamar";
        $querykamar=mysqli_query($koneksi,$sqlkamar);
        ?>
        <div class="col-md-12 mb-2">
            <label for="txttipe_kamar">Tipe kamar</label>
            <select name="txttipe_kamar" id="tipe_kamar">
                <?php
                while($datakamar=mysqli_fetch_assoc($querykamar)){
                    ?>
                    <option value="<?=$datakamar['tipe_kamar'];?>"<?=($datakamar['tipe_kamar']==$data['tipekamar']) ? 'selected': '';?>><?=$datakamar['tipe_kamar'];?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
        <div class="col-md-12 mb-2">
            <label for="datetglpesan">Tanggal Pesan</label>
            <input type="date" name="datetglpesan" id="datetglpesan"
            class="form-control" value="<?=$data['tglpesan'];?>">
        </div>
        <div class="col-md-12 mb-2">
            <label for="txtstatus">Status</label>
            <select name="txtstatus" id="status">
                    <option value="OK" ($data['status']=="OK") ? 'selected' :''>OK</option>
                    <option value="penuh" ($data['status']=="penuh") ? 'selected' : ''>Penuh</option>
                </select>
            </div>
       <div class="mt-3">
            <button type="submit" name="update" class="btn btn-primary">Save</button>
        </div>
    </form>
    <?php
    }
}
    }
    ?>