<?php
    require("../config/reservasi.php");
    /**
     * Halaman untuk tambah data dan update data
     * Cek apakah data id ada, jika ada maka form update
     * jika tidak ada maka form insert
     */
    $reservasi=new reservasi();
    if(isset($_POST['simpan'])){
        $kodepesan=htmlspecialchars(trim($_POST['txtkodepesan']));
        $id_tamu=htmlspecialchars(trim($_POST['txtid_tamu']));
        $checkin=htmlspecialchars(trim($_POST['datecheckin']));
        $checkout=htmlspecialchars(trim($_POST['datecheckout']));
        $tipekamar=htmlspecialchars(trim($_POST['txttipekamar']));
        $tglpesan=htmlspecialchars(trim($_POST['datetglpesan']));
        $status=htmlspecialchars(trim($_POST['txtstatus']));
        $reservasi->simpanreservasi($kodepesan,$checkin,$checkout,$tipekamar,$tglpesan,$status);
       //var_dump($reservasi);die();
        header("location:index.php?modul=reservasi");
    }
    else{
    ?>

    <!-- Buat Form untuk menampilkan data update --> 
    <form action="tambahreservasi.php" method="post">
        <div class="form">
            <label for="txtkodepesan">kodepesan</label>
            <input type="text" name="txtkodepesan" id="txtkodepesan"
            placeholder="kodepesan" required>
        </div>
        <div class="form">
            <label for="txtid_tamu">Id Tamu</label>
            <input type="text" name="txtid_tamu" id="txtid_tamu"
            placeholder="id_tamu" required>
        </div>
        <div class="form">
            <label for="datecheckin">checkin</label>
            <input type="date" name="datecheckin" id="datecheckin"
            placeholder="checkin" required>
        </div>
        <div class="form">
            <label for="datecheckout">checkout</label>
            <input type="date" name="datecheckout" id="datecheckout"
            placeholder="checkout" required>
        </div>
        <div class="form">
            <label for="txttipekamar">tipekamar</label>
            <input type="text" name="txttipekamar" id="txttipekamar"
            placeholder="tipekamar" required>
        </div>
        <div class="form">
            <label for="datetglpesan">tglpesan</label>
            <input type="date" name="datetglpesan" id="datetglpesan"
            placeholder="tglpesan" required>
        </div>
        <div class="form">
            <label for="txtstatus">status</label>
            <input type="txt" name="txtstatus" id="txtstatus"
            placeholder="status" required>
        </div>
        <div class="tombol">
            <button type="submit" name="simpan">Save</button>
        </div>
    </form>
    <?php
    }
    ?>