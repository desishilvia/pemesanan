<?php
    require_once "header.php"
?>

<?php
        if(!isset($_SESSION))
        {
         session_start();
        }
        include'../koneksi.php';
        if(!isset($_SESSION['username'])){
                header('location:../index.php');
        }
        elseif($_SESSION['data']['level']!="resepsionis"){
                header('location:../index.php');
        }
       
?>
    
        <div id="selamat">
    
                <hl class="text-danger"><br>Selamat Datang di halaman respsionis<br><br>
                <img src="../gambar/desi_hotel.jpg" class="rounded-circle">
    
    
        </div>
        <div>
        <?php
                include("isihalresepsionis.php");
                ?>
             </div>
    
                <div id="tentang">

                    <h3>Tentang Kami</h3><br>
                    <p>
                    Hotel ini merupakan hotel terbaik dan ternama di seluruh SEMARANG yang berlokasi di Jalan Kenanga Mekar,Semarang Tengah
                 </p><br>

                </div>
    
                <div id="cekinout">
                    <h3>Check-In &amp; Check-Out</h3><br>
                    <h4>Check-In</h4>
                    <p>Jam Check-In Standar : 12.00 WIB</p>
                    <p>*Waktu check-In dari plan mempunyai prioritas lebih besar</p><br>
                    <h4>Check-Out</h4>
                    <p>Jam Check-Out Standar : 13.00 WIB</p>
                    <p>*Waktu check-Out dari plan mempunyai prioritas lebih besar</p><br>
                </div>
    
    
    <?php
        require_once "footer.php"
    ?>
                
                
    
    