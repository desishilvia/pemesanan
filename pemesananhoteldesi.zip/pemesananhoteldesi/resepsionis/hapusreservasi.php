<?php
   include '../koneksi.php';
   $id=$_GET['id'];
   mysqli_query("DELETE FROM vpemesan WHERE kodepesan='$id'")or die ;
   
   header("location:index.php?modul=reservasi");
?>