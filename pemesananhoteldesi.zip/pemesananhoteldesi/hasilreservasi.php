<?php
require_once('header.php');

if(isset($_GET['data'])){
    $kodepesan=$_GET['data'];
    $sql="Select * from vpemesan where kodepesan='$kodepesan'";
    $query=mysqli_query($koneksi,$sql);
?>
<table class="table-bordered" border=1>
    <tr>
        <th>KodePesan</th>
        <th>Id Tamu</th>
        <th>Nama Tamu</th>
		<th>Email</th>
        <th>check-In</th>
		<th>Check-Out</th>
        <th>Tipekamar</th>
        <th>tglpesan</th>
    </tr>
    <?php
    while($baris=mysqli_fetch_assoc($query)){
        ?>
    <tr>
        <td><?= $baris['kodepesan'];?></td>
        <td><?= $baris['id_tamu'];?></td>
        <td><?= $baris['nama_tamu'];?></td>
        <td><?= $baris['email'];?></td>
        <td><?= $baris['checkin'];?></td>
        <td><?= $baris['checkout'];?></td>
		<td><?= $baris['tipekamar'];?></td>
        <td><?= $baris['tglpesan'];?></td>
    </tr>
    <?php
    }
    ?>
</table>
<button><a href="cetakreservasi.php?data=<?=$kodepesan;?>">cetak</button>
<?php
}
require_once "footer.php";
?>