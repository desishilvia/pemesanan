-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 24 Mar 2022 pada 01.10
-- Versi Server: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pemesanan_hotel_desi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasilitas_hotel`
--

CREATE TABLE `fasilitas_hotel` (
  `id` int(13) NOT NULL,
  `namafasilitas` varchar(50) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fasilitas_hotel`
--

INSERT INTO `fasilitas_hotel` (`id`, `namafasilitas`, `keterangan`, `gambar`) VALUES
(9, 'taman', 'halaman belakang', 'taman.webp');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fasilitas_kamar`
--

CREATE TABLE `fasilitas_kamar` (
  `id` int(11) NOT NULL,
  `tipekamar` varchar(35) NOT NULL,
  `fasilitaskamar` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `fasilitas_kamar`
--

INSERT INTO `fasilitas_kamar` (`id`, `tipekamar`, `fasilitaskamar`) VALUES
(1234, 'standard room', 'wifi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` varchar(13) NOT NULL,
  `tipe_kamar` varchar(20) NOT NULL,
  `jumlah` int(6) NOT NULL,
  `harga_kamar` varchar(45) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `tipe_kamar`, `jumlah`, `harga_kamar`, `gambar`) VALUES
('011', 'superior room', 20, 'Rp.500.000', 'superior.jpg'),
('012', 'single room', 50, 'Rp.200.000', 'single.jpg'),
('013', 'standard room', 30, 'Rp.350.000', 'standardroom.jpg'),
('014', 'Suite room', 15, 'Rp.425.000', 'suiteroom.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesan`
--

CREATE TABLE `pemesan` (
  `kodepesan` int(35) NOT NULL,
  `id_tamu` int(11) DEFAULT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `tipekamar` enum('standard room','superior room','deluxe room','suite room','single room') NOT NULL,
  `tglpesan` date NOT NULL,
  `status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemesan`
--

INSERT INTO `pemesan` (`kodepesan`, `id_tamu`, `checkin`, `checkout`, `tipekamar`, `tglpesan`, `status`) VALUES
(12, 34, '2022-03-22', '2022-03-30', 'suite room', '2022-03-19', 'pemesan'),
(23, 12, '2022-02-01', '2022-02-08', 'standard room', '2022-02-01', 'pemesan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` varchar(11) NOT NULL,
  `nama_petugas` varchar(35) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(32) NOT NULL,
  `telp` varchar(13) NOT NULL,
  `level` enum('admin','resepsionis','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `username`, `password`, `telp`, `level`) VALUES
('123456', 'desi shilvia', 'desi', '23456', '086796543781', 'admin'),
('23456', 'desi shilvia', 'desi123', '1234', '086796543781', 'resepsionis');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tamu`
--

CREATE TABLE `tamu` (
  `id_tamu` int(11) NOT NULL,
  `nama_tamu` varchar(25) NOT NULL,
  `email` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tamu`
--

INSERT INTO `tamu` (`id_tamu`, `nama_tamu`, `email`, `alamat`, `no_telp`) VALUES
(12, 'desi', 'desi04@gmail.com', 'jalan tumpang VI no.11', '087654329810'),
(34, 'intan', 'intan123@gmail.com', 'jalan merbabu no.10', '08814232687');

-- --------------------------------------------------------

--
-- Stand-in structure for view `vpemesan`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `vpemesan` (
`kodepesan` int(35)
,`id_tamu` int(11)
,`nama_tamu` varchar(25)
,`email` varchar(20)
,`checkin` date
,`checkout` date
,`tipekamar` enum('standard room','superior room','deluxe room','suite room','single room')
,`tglpesan` date
,`status` varchar(25)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `vpemesan`
--
DROP TABLE IF EXISTS `vpemesan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vpemesan`  AS  select `pemesan`.`kodepesan` AS `kodepesan`,`pemesan`.`id_tamu` AS `id_tamu`,`tamu`.`nama_tamu` AS `nama_tamu`,`tamu`.`email` AS `email`,`pemesan`.`checkin` AS `checkin`,`pemesan`.`checkout` AS `checkout`,`pemesan`.`tipekamar` AS `tipekamar`,`pemesan`.`tglpesan` AS `tglpesan`,`pemesan`.`status` AS `status` from (`pemesan` join `tamu`) where (`pemesan`.`id_tamu` = `tamu`.`id_tamu`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fasilitas_hotel`
--
ALTER TABLE `fasilitas_hotel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fasilitas_kamar`
--
ALTER TABLE `fasilitas_kamar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indexes for table `pemesan`
--
ALTER TABLE `pemesan`
  ADD PRIMARY KEY (`kodepesan`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tamu`
--
ALTER TABLE `tamu`
  ADD PRIMARY KEY (`id_tamu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fasilitas_hotel`
--
ALTER TABLE `fasilitas_hotel`
  MODIFY `id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
