<?php
    require_once "header.php";

?>

<script type="text/javascript">
    function pilih() {
        var type = document.opsi.tipe.value;
        var teks = document.getElementById('selek').options[document.getElementById('selek').selectedIndex].text;
        document.opsi.harga.value = type;
        document.opsi.tipex.value = teks;

    }
</script>

    <div id="selamat">

            <h1 class="text-success"><br>Selamat Datang<br><br>
            <img src="gambar/desi_hotel.jpg" class="rounded-circle">
    
    </div>

     
                <div id="reservasi">
                <li>Reservasi</li>
                <form method="post" action="user/pemesanan" name="opsi">
                    <table>
                        <tr>
                            <td>Check-In</td>
                            <td>Check-Out</td>
                            <td>Type</td>
                            <td>Harga/malam</td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>
                                <input type="date" name="cekin">
                            </td>
                            <td>
                                <input type="date" name="cekout">
                            </td>
                            <td>
                                <select name="tipe" id="selek" required="required" onchange="pilih()" style="font-weight: bold">
                                <option selected="selected" disabled="disabled">-pilih-</option>
                                <option value="350.000">standard</option>
                                <option value="500.000">superior</option>
                                <option value="470.000">deluxe</option>
                                <option value="425.000">suite</option>
                                <option value="200.000">single</option>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="harga" style="width: 100px;" onchange="pilih()">
                                <input type="hidden" name="tipex" style="width: 100px;" onchange="pilih()">
                            </td>
                            <td>
                                <input type="submit" name="ok" value="Pesan" id="tombol">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>

            <div id="tentang">
                <h3>Tentang Kami</h3><br>
                <p>
                Hotel ini merupakan hotel terbaik dan ternama di seluruh SEMARANG yang berlokasi di Jalan Kenanga Mekar,Semarang Tengah
                </p><br>

            </div>

            <div id="cekinout">
                <h3>Check-In &amp; Check-Out</h3><br>
                <h4>Check-In</h4>
                <p>Jam Check-In Standar : 12.00 WIB</p>
                <p>*Waktu Check-In dari plan mempunyai prioritas lebih besar</p><br>
                <h4>Check-Out</h4>
                <p>Jam Check-out Standar : 13.00 WIB</p>
                <p>*Waktu Check-Out dari plan mempunyai prioritas lebih besar</p><br>
            </div>

    <?php
        require_once "footer.php";
    ?>