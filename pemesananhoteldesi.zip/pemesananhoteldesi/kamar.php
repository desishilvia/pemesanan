<?php
    require_once "header.php";

?>
    <div id="selamat">

            <h1  class="bg-primary text-white"><br>Kamar<br><br>
            <img src="gambar/desi_hotel.jpg"  class="img-thumbnail">
    
    </div>
   <body>
        <table class="table table-dark table-striped" width="90%"height="90%">
        <tr>
            <td>Tipe kamar</td>
            <td>Gambar</td>
            <td>Fasilitas</td>
            <td>Harga kamar</td>
        </tr>
        <tr>
            <td class="text-info">Standard</td>
            <td class="bg-light">
            <img src="gambar/standardroom.jpg" width="60%"height="60%"></td>
            <td>
                <p class="text-secondary">wifi</p>
                <p class="text-secondary">kamar mandi</p>
                <p class="text-secondary">dispenser</p>
                <p class="text-secondary">ac</p>
                <p class="text-secondary">tv</p>
            </td>
            <td class="bg-light"class="text-warning">Rp.350.000</td>
        </tr>
        <tr>
            <td>Superior</td>
            <td class="bg-light">
                <img src="gambar/superior.jpg" width="60%"height="60%"></td>
                <td>
                <p>wifi</p>
                <p>kamar mandi</p>
                <p>dispenser</p>
                <p>meja</p>
                <p>kursi</p>
                <p>ac</p>
                <p>tv</p>
            </td>
            <td class="bg-light">Rp.500.000</td>
        </tr>
        <tr>
            <td class="text-info">Deluxe</td>
            <td class="bg-light">
            <img src="gambar/deluxe.webp" width="60%"height="60%"></td>
            <td>
                <p class="text-secondary">wifi</p>
                <p class="text-secondary">kamar mandi</p>
                <p class="text-secondary">meja</p>
                <p class="text-secondary">ac</p>
                <p class="text-secondary">tv</p>
            </td>
            <td class="bg-light">Rp.470.000</td>
        </tr>
        <tr>
            <td>Suite</td>
            <td>
                <img src="gambar/suiteroom.jpg" width="60%"height="60%"></td>
                <td>
                <p>wifi</p>
                <p>kamar mandi</p>
                <p>ruang tamu</p>
                <p>ac</p>
                <p>tv</p>
            </td>
            <td>Rp.425.000</td>
        </tr>
        <tr>
            <td class="text-info">Single</td>
            <td class="bg-light">
            <img src="gambar/single.jpg" width="60%"height="60%"></td>
                <td>
                <p class="text-secondary">wifi</p>
                <p class="text-secondary">kamar mandi</p>
                <p class="text-secondary">ac</p>
                <p class="text-secondary">tv</p>
            </td>
            <td class="bg-light">Rp200.000</td>
        </tr>
        </table>
</body>
    <?php
        require_once "footer.php";
    ?>