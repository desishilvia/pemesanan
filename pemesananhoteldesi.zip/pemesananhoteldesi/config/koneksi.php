<?php
    include "dbconfig.php";
    /**
     * Nama class : koneksi
     * Class untuk membuat koneksi ke database mysql
     */
    class koneksi
    {
        /**
         * Fungsi construct 
         * @param DBSERVER, DBUSERNAME, DBPASSWORD, DBDATABASE
         * @return koneksi
         **/

        public $conn;
        public function __Construct()
        {
            $this->conn=new mysqli(DBSERVER, DBUSERNAME, DBPASSWORD, DBDATABASE);
            if(mysqli_connect_error()){
                echo "Error:Couldn't connect to database";
                exit;
            }
        }
    }
?>