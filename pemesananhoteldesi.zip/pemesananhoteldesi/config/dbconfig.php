<?php
    define('DBSERVER','localhost');
    define('DBUSERNAME','root');
    define('DBPASSWORD','');
    define('DBDATABASE','pemesanan_hotel_desi');
?>