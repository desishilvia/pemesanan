<?php
require("koneksi.php");
/**
 * Nama class : class admin turunan class koneksi
 * Fungsi     : berisi fungsi untun operasi crud tabel admin
 * Versi      : 1
 * Pembuat    : dshilvia_
 * Dependensi : koneksi.php
 */
class reservasi extends koneksi
{
    /**
     * Nama Fungsi : tampil_Data
     * Fungsi      : menampilkan semua data tabel
     * @param null
     * @return array
     **/
    public function tampilpemesan()
    {
        $sql="Select * from pemesan";
        $query = $this->conn->query($sql);
        while ($hasil = $query->fetch_assoc()) {
            $baris[] = $hasil;
        }
        if(!empty($baris)){
            return $baris;
        }
    }

    /**
     * Nama Fungsi : tampil_Data
     * Fungsi      : menampilkan semua data tabel
     * @param null
     * @return array
     **/
    public function tampilcheckin()
    {
        $sql="Select * from checkin";
        $query = $this->conn->query($sql);
        while ($hasil = $query->fetch_assoc()) {
            $baris[] = $hasil;
        }
        if(!empty($baris)){
            return $baris;
        }
    }

    /**
     * Nama Fungsi : cariDataById
     * Fungsi      : Mencari data berdasarkan data username
     * @param string $id untuk menampung data username
     * @return array 
     **/
    public function carireservasiById($kodepesan)
    {
        $sql="select kodepesan,id_tamu,nama_tamu,email,checkin,checkout,tipekamar,tglpesan,status
        from pemesan where kodepesan='$id'";
        $admin=$this->conn->query($sql);
        return $admin;
       /*  while($hasil=$pemesan->fetch_assoc()){
            $baris[]=$hasil;
        } 
        if(!empty($baris)){
            return $baris;
        } */
    }

    /**
     * Nama Fungsi : cariDataById
     * Fungsi      : Mencari data berdasarkan data username
     * @param string $id untuk menampung data username
     * @return array 
     **/
    public function caricheckinById($id)
    {
        $sql="select id,tipekamar,fasilitaskamar
        from check-in where id='$id'";
        $admin=$this->conn->query($sql);
        return $admin;
       /*  while($hasil=$checkin->fetch_assoc()){
            $baris[]=$hasil;
        } 
        if(!empty($baris)){
            return $baris;
        } */
    }

    /**
     * Nama Fungsi : updatepemesan
     * Fungsi      : Update pemesan
     * @param objek $data data untuk update
     * @return void
     **/
    public function updatepemesan($kodepesan,$checkin,$checkout,$tipekamar,$tglpesan,$status)
    {
        $sqlupdate="update pemesan set kodepesan='$kodepesan',check-in='$check-in',check-out='$check-out',tipekamar='$tipekamar',tglpesan='$tglpesan',status='$status' where kodepesan='$kodepesan'";
        $this->conn->query($sqlupdate);
    }

     /**
     * Nama Fungsi : updatecheckin
     * Fungsi      : Update checkin
     * @param objek $data data untuk update
     * @return void
     **/
    public function updatefasilitas_kamar($id,$tipekamar,$fasilitaskamar)
    {
        $sqlupdate="update fasilitas_kamar set id='$id',tipekamar='$tipekamar',fasilitaskamar='$fasilitaskamar' where id='$id'";
        $this->conn->query($sqlupdate);
    }

    /**
     * Nama Fungsi : hapuspemesan
     * Fungsi      : Menghapus data berdasarkan data username
     * @param string $id 
     * @return void
     **/
    public function hapuspemesan($kodepesan)
    {
        $sqlhapuspemesan="delete from pemesan where kodepesan='$kodepesan'";
        $this->conn->query($sqlhapuspemesan);
    }
    /**
     * Nama Fungsi : hapusfasilitas_kamar
     * Fungsi      : Menghapus data berdasarkan data username
     * @param string $id 
     * @return void
     **/
    public function hapusfasilitas_kamar($id)
    {
        $sqlhapusfasilitas_kamar="delete from fasilitas_kamar where id='$id'";
        $this->conn->query($sqlhapusfasilitas_kamar);
    }

    /**
     * Nama Fungsi : simpanpemesan
     * Fungsi      : menyimpan data
     * @param array $data
     * @return void
     **/
    public function simpanreservasi($kodepesan,$checkin,$checkout,$tipekamar,$tglpesan,$status)
    {
        $sqlsave="insert into pemesan(kodepesan,check-in,check-out,tipekamar,tglpesan,status) values ('$kodepesan','$check-in','$check-out','$tipekamar','$tglpesan','$status')";
        $this->conn->query($sqlsave);
    }

 /**
     * Nama Fungsi : simpancheckin
     * Fungsi      : menyimpan data
     * @param array $data
     * @return void
     **/
    public function simpancheckin($id,$tipekamar,$fasilitaskamar)
    {
        $sqlsave="insert into fasilitas_kamar(id,tipekamar,fasilitaskamar) values ('$id','$tipekamar','$fasilitaskamar')";
        $this->conn->query($sqlsave);
    }
}