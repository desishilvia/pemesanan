<?php
require("koneksi.php");
/**
 * Nama class : class admin turunan class koneksi
 * Fungsi     : berisi fungsi untuk operasi crud tabel admin
 * Versi      : 1
 * Pembuat    : dshilvia_
 * Dependensi : koneksi.php
 */
class Admin extends koneksi
{
    /**
     * Nama Fungsi : tampil_Data
     * Fungsi      : menampilkan semua data tabel
     * @param null
     * @return array
     **/
    public function tampilkamar()
    {
        $sql="Select * from kamar";
        $query = $this->conn->query($sql);
        while ($hasil = $query->fetch_assoc()) {
            $baris[] = $hasil;
        }
        if(!empty($baris)){
            return $baris;
        }
    }

    /**
     * Nama Fungsi : tampil_Data
     * Fungsi      : menampilkan semua data tabel
     * @param null
     * @return array
     **/
    public function tampilfasilitas_hotel()
    {
        $sql="Select * from fasilitas_hotel";
        $query = $this->conn->query($sql);
        while ($hasil = $query->fetch_assoc()) {
            $baris[] = $hasil;
        }
        if(!empty($baris)){
            return $baris;
        }
    }

    /**
     * Nama Fungsi : tampil_Data
     * Fungsi      : menampilkan semua data tabel
     * @param null
     * @return array
     **/
    public function tampilfasilitas_kamar()
    {
        $sql="Select * from fasilitas_kamar";
        $query = $this->conn->query($sql);
        while ($hasil = $query->fetch_assoc()) {
            $baris[] = $hasil;
        }
        if(!empty($baris)){
            return $baris;
        }
    }

    /**
     * Nama Fungsi : cariDataById
     * Fungsi      : Mencari data berdasarkan data username
     * @param string $id untuk menampung data username
     * @return array 
     **/
    public function carikamarById($id)
    {
        $sql="select id_kamar,tipe_kamar,jumlah,harga_kamar,gambar
        from kamar where id_kamar='$id'";
        $admin=$this->conn->query($sql);
        return $admin;
       /*  while($hasil=$kamar->fetch_assoc()){
            $baris[]=$hasil;
        } 
        if(!empty($baris)){
            return $baris;
        } */
    }

    /**
     * Nama Fungsi : cariDataById
     * Fungsi      : Mencari data berdasarkan data username
     * @param string $id untuk menampung data username
     * @return array 
     **/
    public function carifasilitas_kamarById($id)
    {
        $sql="select id,tipekamar,fasilitaskamar
        from fasilitas_kamar where id='$id'";
        $admin=$this->conn->query($sql);
        return $admin;
       /*  while($hasil=$fasilitas_kamar->fetch_assoc()){
            $baris[]=$hasil;
        } 
        if(!empty($baris)){
            return $baris;
        } */
    }

    /**
     * Nama Fungsi : cariDataById
     * Fungsi      : Mencari data berdasarkan data username
     * @param string $id untuk menampung data username
     * @return array 
     **/
    public function carifasilitas_hotelById($id)
    {
        $sql="select id,namafasilitas,keterangan,gambar
        from fasilitas_hotel where id='$id'";
        $admin=$this->conn->query($sql);
        return $admin;
       /*  while($hasil=$fasilitas_hotel->fetch_assoc()){
            $baris[]=$hasil;
        } 
        if(!empty($baris)){
            return $baris;
        } */
    }
    /**
     * Nama Fungsi : updatekamar
     * Fungsi      : Update kamar
     * @param objek $data data untuk update
     * @return void
     **/
    public function updatekamar($id_kamar,$tipe_kamar,$jumlah,$harga_kamar,$gambar)
    {
        $sqlupdate="update kamar set id_kamar='$id_kamar',tipe_kamar='$tipe_kamar',jumlah='$jumlah',harga_kamar='$harga_kamar',gambar='$gambar' where id_kamar='$id_kamar'";
        $this->conn->query($sqlupdate);
    }

     /**
     * Nama Fungsi : updatefasilitas_kamar
     * Fungsi      : Update fasilitas_kamar
     * @param objek $data data untuk update
     * @return void
     **/
    public function updatefasilitas_kamar($id,$tipekamar,$fasilitaskamar)
    {
        $sqlupdate="update fasilitas_kamar set id='$id',tipekamar='$tipekamar',fasilitaskamar='$fasilitaskamar' where id='$id'";
        $this->conn->query($sqlupdate);
    }

     /**
     * Nama Fungsi : updatefasilitas_hotel
     * Fungsi      : Update fasilitas_hotel
     * @param objek $data data untuk update
     * @return void
     **/
    public function updatefasilitas_hotel($id,$namafasilitas,$keterangan,$gambar)
    {
        $sqlupdate="update fasilitas_hotel set id='$id',namafasilitas='$namafasilitas',keterangan='$keterangan',gambar='$gambar' where id='$id'";
        $this->conn->query($sqlupdate);
    }
    /**
     * Nama Fungsi : hapuskamar
     * Fungsi      : Menghapus data berdasarkan data username
     * @param string $id 
     * @return void
     **/
    public function hapuskamar($id_kamar)
    {
        $sqlhapuskamar="delete from kamar where id_kamar='$id_kamar'";
        $this->conn->query($sqlhapuskamar);
    }
    /**
     * Nama Fungsi : hapusfasilitas_kamar
     * Fungsi      : Menghapus data berdasarkan data username
     * @param string $id 
     * @return void
     **/
    public function hapusfasilitas_kamar($id)
    {
        $sqlhapusfasilitas_kamar="delete from fasilitas_kamar where id='$id'";
        $this->conn->query($sqlhapusfasilitas_kamar);
    }

    /**
     * Nama Fungsi : hapusfasilitas_hotel
     * Fungsi      : Menghapus data berdasarkan data username
     * @param string $id 
     * @return void
     **/
    public function hapusfasilitas_hotel($id)
    {
        $sqlhapusfasilitas_hotel="delete from fasilitas_hotel where id='$id'";
        $this->conn->query($sqlhapusfasilitas_hotel);
    }

    /**
     * Nama Fungsi : simpankamar
     * Fungsi      : menyimpan data
     * @param array $data
     * @return void
     **/
    public function simpankamar($id_kamar,$tipe_kamar,$jumlah,$harga_kamar,$gambar)
    {
        $sqlsave="insert into kamar(id_kamar,tipe_kamar,jumlah,harga_kamar,gambar) values ('$id_kamar','$tipe_kamar','$jumlah','$harga_kamar','$gambar')";
        $this->conn->query($sqlsave);
    }

 /**
     * Nama Fungsi : simpanfasilitas_kamar
     * Fungsi      : menyimpan data
     * @param array $data
     * @return void
     **/
    public function simpanfasilitas_kamar($id,$tipekamar,$fasilitaskamar)
    {
        $sqlsave="insert into fasilitas_kamar(id,tipekamar,fasilitaskamar) values ('$id','$tipekamar','$fasilitaskamar')";
        $this->conn->query($sqlsave);
    }
     /**
     * Nama Fungsi : simpanfasilitas_hotel
     * Fungsi      : menyimpan data
     * @param array $data
     * @return void
     **/
    public function simpanfasilitas_hotel($id,$namafasilitas,$keterangan,$gambar)
    {
        $sqlsave="insert into fasilitas_hotel(id,namafasilitas,keterangan,gambar) values ('$id','$namafasilitas','$keterangan','$gambar')";
        $this->conn->query($sqlsave);
    }
}