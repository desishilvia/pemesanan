<?php
require_once('header.php');

if(isset($_GET['data'])){
    $kodepesan=$_GET['data'];
    $sql="Select * from vpemesan where kodepesan='$kodepesan'";
    $query=mysqli_query($koneksi,$sql);
?>
<h2>Bukti Pemesanan Hotel<h2>
    <table class="table">
        <?php
        while($baris=mysqli_fetch_assoc($query)){
            ?>
    <tr>
        <td>KodePesan</td>
        <td><?=$baris['kodepesan'];?></td>
    </tr>
    <tr>
        <td>Id Tamu</td>
        <td><?=$baris['id_tamu'];?></td>
    </tr>
    <tr>
        <td>Nama Tamu</td>
        <td><?=$baris['nama_tamu'];?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><?=$baris['email'];?></td>
    </tr>
    <tr>
        <td>Checkin</td>
        <td><?=$baris['checkin'];?></td>
    </tr>
    <tr>
        <td>Checkout</td>
        <td><?=$baris['checkout'];?></td>
    </tr>
    <tr>
        <td>Tipe Kamar</td>
        <td><?=$baris['tipekamar'];?></td>
    </tr>
    <tr>
        <td>Tanggal Pesan</td>
        <td><?=$baris['tglpesan'];?></td>
    </tr>

    <?php
    }
    ?>
    </table>
<?php
}
?>