<?php
    require_once "header.php";

?>
    <div id="selamat">

            <h1 class="bg-success text-white"><br>fasilitas<br><br>
            <img src="gambar/desi_hotel.jpg" class="img-thumbnail">
    
    </div>
   <body>
        <table class="table table-striped" width="90%"height="90%">
        <tr>
            <td>fasilitas</td>
            <td>Gambar</td>
        </tr>
        <tr>
            <td class="text-info">Wifi</td>
            <td class="bg-primary">
            <img src="gambar/download.png" width="55%"height="55%"></td>
        </tr>
        <tr>
            <td class="bg-primary">Kolam Renang</td>
            <td>
            <img src="gambar/desi KR.jpeg" width="55%"height="55%"></td>
        </tr>
        <tr>
            <td class="text-info">Pemandian air panas</td>
            <td class="bg-primary">
                <img src="gambar/pemandianairpanas.jpg" width="55%"height="55%"></td>
        </tr>
        <tr>
            <td class="bg-primary">Taman</td>
            <td>
            <img src="gambar/taman.webp" width="55%"height="55%"></td>
        </tr>
        <tr>
            <td class="text-info">Restoran Indoor</td>
            <td class="bg-primary">
                <img src="gambar/DESI REST.jpg" width="55%"height="55%"></td>
         <td class="text-info">Restoran Outdoor</td>
         <td>
            <img src="gambar/restoran.jpg" width="55%"height="55%"></td>
        </tr>
        </table>
</body>
    <?php
        require_once "footer.php";
    ?>