<?php
require_once "header.php";

if(isset($_POST['pesan'])) {
    $kodepesan=$_POST['kodepesan'];
    $id_tamu=$_POST['id_tamu'];
    $checkin=$_POST['checkin'];
    $checkout=$_POST['checkout'];
    $tipe_kamar=$_POST['tipe_kamar'];
    $tglpesan=$_POST['tglpesan'];
    $nama_tamu=$_POST['nama_tamu'];
    $email=$_POST['email'];
    $alamat=$_POST['alamat'];
    $no_telp=$_POST['no_telp'];
    
    $sql1="insert into pemesan(kodepesan,id_tamu,checkin,checkout,tipekamar,tglpesan,status)
    values('$kodepesan','$id_tamu','$checkin','$checkout','$tipe_kamar','$tglpesan','')";
    $sql2="insert into tamu(id_tamu,nama_tamu,email,alamat,no_telp) values('$id_tamu','$nama_tamu','$email','$alamat','$no_telp')";
    //var_dump($sql1);var_dump($sql2);die();
    mysqli_query($koneksi,$sql1);
    mysqli_query($koneksi,$sql2);
    header("location:hasilreservasi.php?data=$kodepesan");
}
// else{
//     if(isset($_GET['id'])){
//         $id=$_GET['id'];
//         $sql="select * from vpemesan where kodepesan='$id'";
//         $query=mysqli_query($koneksi,$sql);
//         while($data=mysqli_fetch_assoc($query)){
        
?>
<!-- <form action="" method="Post">
  <div class="mb-3 mt-3">
    <label for="kodepesan" class="form-label">Kode pesan</label>
    <input type="kodepesan" class="form-control" id="kodepesan" placeholder="kode pesan" name="txtkodepesan">
  </div>
  <div class="mb-3">
    <label for="pwd" class="form-label">Password:</label>
    <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd">
  </div>
  <div class="form-check mb-3">
    <label class="form-check-label">
      <input class="form-check-input" type="checkbox" name="remember"> Remember me
    </label>
  </div> -->
  <!-- <button type="submit" class="btn btn-primary">Submit</button>
</form> -->

<div id="page" style="margin-top: 60px;">
<center>
  <div id="page table">
    <h4 class="bg-danger">Pemesanan Reservasi</h4>
      <form method="POST" action="reservasi.php">
  <div class="mb-3">
    <label for="kodepesan" class="form-label">Kode Pesan</label>
    <input type="text" class="form-control" name="kodepesan" id="kodepesan">
  </div>
  <div class="mb-3">
    <label for="id_tamu" class="form-label">Id Tamu</label>
    <input type="text" class="form-control" name="id_tamu" id="id_tamu">
  </div>
  <div class="mb-3">
    <label for="nama_tamu" class="form-label">Nama Tamu</label>
    <input type="text" class="form-control" name="nama_tamu" id="nama_tamu">
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="text" class="form-control" name="email" id="email">
  </div>
  <div class="mb-3">
    <label for="alamat" class="form-label">Alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat">
  </div>
  <div class="mb-3">
    <label for="no_telp" class="form-label">No Telp</label>
    <input type="text" class="form-control" name="no_telp" id="no_telp">
  </div>
  <div class="mb-3">
    <label for="checkin" class="form-label">Check In</label>
    <input type="date" class="form-control" name="checkin" id="checkin">
  </div>
  <div class="mb-3">
    <label for="checkout" class="form-label">Check Out</label>
    <input type="date" class="form-control" name="checkout" id="checkout">
  </div>
  <?php
        $sqlkamar="select tipe_kamar from kamar";
        $querykamar=mysqli_query($koneksi,$sqlkamar);
        ?>
        <div class="mb-3">
            <label for="txttipe_kamar">Tipe kamar</label>
            <select name="tipe_kamar" id="tipe_kamar">
                <?php
                while($datakamar=mysqli_fetch_assoc($querykamar)){
                    ?>
                    <option value="<?=$datakamar['tipe_kamar'];?>"><?=$datakamar['tipe_kamar'];?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
  <div class="mb-3">
    <label for="tglpesan" class="form-label">Tanggal Pesan</label>
    <input type="date" class="form-control" name="tglpesan" id="tglpesan">
  </div>

  <button type="submit" class="btn btn-primary" name="pesan">Pesan</button>
</form>


<?php
require_once "footer.php"
?>