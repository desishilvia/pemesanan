<?php
require('../config/admin.php');
/**
 * Halaman profile untuk menampilkan data admin
 */
$admin=new admin();
$baris=$admin->tampilfasilitas_hotel();
?>
<!--Membuat tabel data admin-->
<a href="index.php?modul=fasilitashotel&aksi=tambah"><button>Tambah Data</button></a>
<table class="table-bordered" border=1>
    <tr>
        <th>id</th>
        <th>namafasilitas</th>
        <th>keterangan</th>
        <th>gambar</th>
        <th colspan="2" style="text-align: center;">Aksi</th>
    </tr>
    <?php
    foreach($baris as $barisadmin){
        ?>
    <tr>
        <td><?= $barisadmin['id'];?></td>
        <td><?= $barisadmin['namafasilitas'];?></td>
        <td><?= $barisadmin['keterangan'];?></td>
        <td><?= $barisadmin['gambar'];?></td>
        <td><a href="index.php?modul=fasilitashotel&aksi=update&id=<?= $barisadmin['id'];?>">Update</a></td>
        <td><a href="index.php?modul=fasilitashotel&aksi=delete&id=<?= $barisadmin['id'];?>">Delete</a></td>
    </tr>
    <?php
    }
    ?>
</table>