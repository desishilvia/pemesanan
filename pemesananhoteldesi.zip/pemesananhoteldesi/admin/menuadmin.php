<ul>
    <li><a href="index.php?modul=kamar">kamar</a></li>
    <li><a href="index.php?modul=fasilitas">fasilitas</a></li>
    <li><a href="../logout.php">Logout</a></li>
</ul>