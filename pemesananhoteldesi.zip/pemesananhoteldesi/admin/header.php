<?php
    session_start();
    //require_once "../koneksi.php";
    if(isset($_SESSION['user'])) {
        echo "<scrpit>window.location.replace('user/')</script>";
     }
     else {
         unset($_SESSION['user']);
     }
?>

<!DOCTYPE html>
<html>
<head>
     <title>Halaman Admin</title>
     <meta charset="utf-8">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <link rel="stylesheet" type="text/css" href="../css/styles.css">
     <script type="text/javascript" src="lib/sweet.js"></script>
     <style type="text/css">


     </style>
</head>
<body>

        <nav>
            <h1>Halaman Admin </h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php?modul=kamar">Kamar</a></li>
                <li><a href="index.php?modul=fasilitaskamar">Fasilitas Kamar</a></li>
                <li><a href="index.php?modul=fasilitashotel">Fasilitas Hotel</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </nav>
        <?php
             
            
		     ?>
        <main>
            <center>
            <!-- <div id="log-in">
                <div class="isi_popup2">

                <center>
                <li>Silahkan Login</li>
                <form method="POST" action="index">
                    <table align="center">
                        <tr>
                        <td>Email</td>
                        <td>input type="Email" name="Email" required="required" placeholder="Email"></td>
                        </tr>
                        <tr>
                            <td>Pasword</td>
                            <td>input type="password" name="password" required="required" placeholder="kata sandi"></td>
                        </tr>
                        </table>
                                <a href="index"><button type="submit" name="submit" id="tomboll" style="width: 63px;">Login</button></a>
                                    <a href="#" style="background-color:#000;color:white;font-weight:bold;border:2px solid white;padding: 8px; text-decoration: none;">Batal</a>

                        </form>
                        </center>
                    </div>
                </div> -->
