<?php
    require("../config/admin.php");
    /**
     * Halaman untuk tambah data dan update data
     * Cek apakah data id ada, jika ada maka form update
     * jika tidak ada maka form insert
     */
    $admin=new admin();
    if(isset($_POST['simpan'])){
        $id=htmlspecialchars(trim($_POST['txtid']));
        $tipekamar=htmlspecialchars(trim($_POST['txttipekamar']));
        $fasilitaskamar=htmlspecialchars(trim($_POST['txtfasilitaskamar']));
        $admin->updatefasilitas_kamar($id,$tipekamar,$fasilitaskamar);
        //var_dump($admin);die();
        header("location:index.php?modul=fasilitaskamar");
    }
    else{
        if(isset($_GET['id'])){
            $id=$_GET['id'];
            $data=$admin->carifasilitas_kamarById($id);
            foreach($data as $dataadmin){
    ?>
    <!-- Buat Form untuk menampilkan data update --> 
    <form action="updatefasilitaskamar.php" method="post">
        <div class="form">
            <label for="txtid">id</label>
            <input type="text" name="txtid" id="txtid"
            placeholder="txtid" value="<?=$dataadmin['id'];?>">
        </div>
        <div class="form">
            <label for="txttipekamar">tipekamar</label>
            <input type="text" name="txttipekamar" id="txttipekamar"
            placeholder="txttipekamar" value="<?=$dataadmin['tipekamar'];?>">
        </div>
        <div class="form">
            <label for="txtfasilitaskamar">fasilitaskamar</label>
            <input type="text" name="txtfasilitaskamar" id="txtfasilitaskamar"
            placeholder="txtfasilitaskamar" value="<?=$dataadmin['fasilitaskamar'];?>">
        </div>
        <div class="tombol">
            <button type="submit" name="simpan">Save</button>
        </div>
    </form>
    <?php
    }
}
    }
    ?>