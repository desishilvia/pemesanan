<?php
    require("../config/admin.php");
    /**
     * Halaman untuk tambah data dan update data
     * Cek apakah data id ada, jika ada maka form update
     * jika tidak ada maka form insert
     */
    $kamar=new Admin();
    if(isset($_POST['simpan'])){
        $Id_kamar=htmlspecialchars(trim($_POST['txtid_kamar']));
        $Tipe_kamar=htmlspecialchars(trim($_POST['txttipe_kamar']));
        $jumlah=htmlspecialchars(trim($_POST['txtjumlah']));
        $harga_kamar=htmlspecialchars(trim($_POST['txtharga_kamar']));
        //proses upload gambar
        move_uploaded_file($_FILES["txtgambar"]["tmp_name"],"../gambar/".$_FILES["txtgambar"]["name"]);
        $gambar=htmlspecialchars(trim($_FILES['txtgambar']['name']));
        //Akhir proses upload
        $kamar->simpankamar($Id_kamar,$Tipe_kamar,$jumlah,$harga_kamar,$gambar);
        //var_dump($kamar);die();
        header("location:index.php?modul=kamar");
    }
    else{
    ?>

    <!-- Buat Form untuk menampilkan data update --> 
    <form action="tambahkamar.php" method="post" enctype="multipart/form-data">
        <div class="form">
            <label for="txtid_kamar">Id_kamar</label>
            <input type="text" name="txtid_kamar" id="txtid_kamar"
            placeholder="id_kamar" required>
        </div>
        <div class="form">
            <label for="txttipe_kamar">tipe_kamar</label>
            <input type="text" name="txttipe_kamar" id="txttipe_kamar"
            placeholder="tipe_kamar" required>
        </div>
        <div class="form">
            <label for="txtjumlah">jumlah</label>
            <input type="text" name="txtjumlah" id="txtjumlah"
            placeholder="jumlah" required>
        </div>
        <div class="form">
            <label for="txtharga_kamar">harga_kamar</label>
            <input type="text" name="txtharga_kamar" id="txtharga_kamar"
            placeholder="harga_kamar" required>
        </div>
        <div class="form">
            <label for="txtgambar">gambar</label>
            <input type="file" name="txtgambar" id="txtgambar"
            placeholder="gambar" required>
        </div>
        <div class="tombol">
            <button type="submit" name="simpan">Save</button>
        </div>
    </form>
    <?php
    }
    ?>