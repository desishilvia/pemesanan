<?php
    require("../config/admin.php");
    /**
     * Halaman untuk tambah data dan update data
     * Cek apakah data id ada, jika ada maka form update
     * jika tidak ada maka form insert
     */
    $admin=new Admin();
    if(isset($_POST['simpan'])){
        $id=htmlspecialchars(trim($_POST['txtid']));
        $namafasilitas=htmlspecialchars(trim($_POST['txtnamafasilitas']));
        $keterangan=htmlspecialchars(trim($_POST['txtketerangan']));
          //proses upload gambar
          move_uploaded_file($_FILES["txtgambar"]["tmp_name"],"../gambar/".$_FILES["txtgambar"]["name"]);
          $gambar=htmlspecialchars(trim($_FILES['txtgambar']['name']));
          //Akhir proses upload
        $admin->updatefasilitas_hotel($id,$namafasilitas,$keterangan,$gambar);
        header("location:index.php?modul=fasilitashotel");
    }
    else{
        if(isset($_GET['id'])){
            $id=$_GET['id'];
            $data=$admin->carifasilitas_hotelById($id);
            foreach($data as $dataadmin){
    ?>

    <!-- Buat Form untuk menampilkan data update --> 
    <form action="updatefasilitashotel.php" method="post" enctype="multipart/form-data">
        <div class="form">
            <label for="txtid">id</label>
            <input type="text" name="txtid" id="txtid"
            placeholder="txtid" value="<?=$dataadmin['id'];?>">
        </div>
        <div class="form">
            <label for="txtnamafasilitas">namafasilitas</label>
            <input type="text" name="txtnamafasilitas" id="txtnamafasilitas"
            placeholder="namafasilitas" value="<?=$dataadmin['namafasilitas'];?>">
        </div>
        <div class="form">
            <label for="txtketerangan">keterangan</label>
            <input type="text" name="txtketerangan" id="txtketerangan"
            placeholder="txtketerangan" value="<?=$dataadmin['keterangan'];?>">
        </div>
        <div class="form">
            <label for="txtgambar">gambar</label>
            <input type="file" name="txtgambar" id="txtgambar"
            placeholder="gambar" value="<?=$dataadmin['gambar'];?>">
        </div>
        <div class="tombol">
            <button type="submit" name="simpan">Save</button>
        </div>
    </form>
    <?php
    }
}
    }
    ?>