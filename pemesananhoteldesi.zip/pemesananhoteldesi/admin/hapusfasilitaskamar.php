<?php
    require("../config/admin.php");
    /**
     * Halaman untuk hapus data
     * Cek apakah data id ada, jika ada proses hapus dikerjakan
     */
    $admin=new Admin();
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $admin->hapusfasilitas_kamar($id);
        header("location:index.php?modul=fasilitaskamar");
    }
?>