<?php
    if(isset($_GET['modul'])){
        $page=$_GET['modul'];
        switch ($page) {
            case 'kamar':
                if(isset($_GET['aksi'])){
                    $act=$_GET['aksi'];
                    switch ($act) {
                        case 'tambah':
                            include("tambahkamar.php");
                            break;
                        case 'update':
                            include("updatekamar.php");
                            break;
                        case 'delete':
                            include("hapuskamar.php");
                            break;
                    }
                }
                else{
                    include "datakamar.php";
                    break;
                }
                break;
            case 'fasilitaskamar':
                if(isset($_GET['aksi'])){
                    $act=$_GET['aksi'];
                    switch ($act) {
                        case 'tambah':
                            include("tambahfasilitaskamar.php");
                            break;
                        case 'update':
                            include("updatefasilitaskamar.php");
                            break;
                        case 'delete':
                            include("hapusfasilitaskamar.php");
                            break;
                    }
                }
                else{
                    include "datafasilitaskamar.php";
                    break;
                }
                break;
                case 'fasilitashotel':
                    if(isset($_GET['aksi'])){
                        $act=$_GET['aksi'];
                        switch ($act) {
                            case 'tambah':
                                include("tambahfasilitashotel.php");
                                break;
                            case 'update':
                                include("updatefasilitashotel.php");
                                break;
                            case 'delete':
                                include("hapusfasilitashotel.php");
                                break;
                        }
                    }
                    else{
                        include "datafasilitashotel.php";
                        break;
                    }
                    break;
        }
    }
?>