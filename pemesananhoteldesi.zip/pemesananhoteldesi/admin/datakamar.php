<?php
require('../config/admin.php');
/**
 * Halaman profile untuk menampilkan data admin
 */
$kamar=new admin();
$baris=$kamar->tampilkamar();
?>
<!--Membuat tabel data admin-->
<a href="index.php?modul=kamar&aksi=tambah"><button>Tambah Data</button></a>
<table class="table-bordered" border=1>
    <tr>
        <th>id_kamar</th>
        <th>tipe_kamar</th>
		<th>jumlah</th>
        <th>harga_kamar</th>
        <th>gambar</th>
        <th colspan="2" style="text-align: center;">Aksi</th>
    </tr>
    <?php
    foreach($baris as $barisadmin){
        ?>
    <tr>
        <td><?= $barisadmin['id_kamar'];?></td>
        <td><?= $barisadmin['tipe_kamar'];?></td>
        <td><?= $barisadmin['jumlah'];?></td>
		<td><?= $barisadmin['harga_kamar'];?></td>
        <td><?= $barisadmin['gambar'];?></td>
        <td><a href="index.php?modul=kamar&aksi=update&id=<?= $barisadmin['id_kamar'];?>">Update</a></td>
        <td><a href="index.php?modul=kamar&aksi=delete&id=<?= $barisadmin['id_kamar'];?>">Delete</a></td>
    </tr>
    <?php
    }
    ?>
</table>
