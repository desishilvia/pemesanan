<?php
$koneksi=mysqli_connect("localhost","root","","pemesanan_hotel_desi");
?>